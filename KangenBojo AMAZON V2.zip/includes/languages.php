<?php
// Language detection removed per admin request. This file kept empty to avoid errors.
// Intentionally left blank to preserve backwards-compatibility when included.

